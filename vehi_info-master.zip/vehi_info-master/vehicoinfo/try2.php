<html>
<head></head>
<body>
<input type="search" />
<input type="submit"/>
</body>
</html>