# vehi_info
This web portal  is a useful product deigned to handle various type of information regarding vehicles .
This website could be used by - 
 Owner of vehicle 
Vehicle company
RTO office
Traffic police
Insurance company
This web portal will contain details of insurance of vehicle, pollution card for the vehicle ,information of
permits.
this will provide a special portal for police which helps in reducing thefts.
Online Number Plate will also be generate through our web portal.
